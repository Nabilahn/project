<!DOCTYPE html>
<html>
	<head>
		<title>4 Delicious</title>
		<link rel="icon" href="cup.png" type="image/jpg" sizes="16x16">
	</head>
	<body>


<?php

session_start();
session_unset();
session_destroy();
header("Location: index.php");
?>
</body>
</html>