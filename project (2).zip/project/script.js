function tukarair(){
  document.getElementById("myImage").src="thank.jpg";
}
function tukarmakan(){
  document.getElementById("myImage").src="ice2.jpg";
}
